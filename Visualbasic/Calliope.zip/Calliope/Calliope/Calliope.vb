﻿Public Class Calliope

    Private Sub RichTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RichTextBox1.TextChanged
        RichTextBox1.Text = AxWinsock1.LocalIP
    End Sub

    Private Function AxWinsock1() As Object
        Throw New NotImplementedException
    End Function

End Class
