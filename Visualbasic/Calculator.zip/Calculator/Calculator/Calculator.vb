﻿Public Class Calculator

    Dim firstnumber As Single
    Dim secondnumber As Single
    Dim result As Single
    Dim arithmeticprocess As String

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        Select Case e.KeyCode

            Case Keys.NumPad0

                Button14.PerformClick()

            Case Keys.NumPad1

                Button11.PerformClick()

            Case Keys.NumPad2

                Button12.PerformClick()

            Case Keys.NumPad3

                Button13.PerformClick()

            Case Keys.NumPad4

                Button8.PerformClick()

            Case Keys.NumPad5

                Button9.PerformClick()

            Case Keys.NumPad6

                Button10.PerformClick()

            Case Keys.NumPad7

                Button5.PerformClick()

            Case Keys.NumPad8

                Button6.PerformClick()

            Case Keys.NumPad9

                Button7.PerformClick()
            Case Keys.Decimal

                Button15.PerformClick()
            Case Keys.Multiply

                Button3.PerformClick()
            Case Keys.Divide

                Button4.PerformClick()

            Case Keys.Subtract

                Button2.PerformClick()
            Case Keys.Add

                Button1.PerformClick()
            Case Keys.Enter

                Button16.PerformClick()

        End Select

    End Sub

    Private Sub Calculator_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Text = 0

    End Sub


    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        firstnumber = Val(TextBox1.Text)
        TextBox1.Text = "0"
        arithmeticprocess = "+"
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        firstnumber = Val(TextBox1.Text)
        TextBox1.Text = "0"
        arithmeticprocess = "-"
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        firstnumber = Val(TextBox1.Text)
        TextBox1.Text = "0"
        arithmeticprocess = "*"
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        firstnumber = Val(TextBox1.Text)
        TextBox1.Text = "0"
        arithmeticprocess = "/"
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        TextBox1.Text = TextBox1.Text & "1"
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        TextBox1.Text = TextBox1.Text & "2"
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        TextBox1.Text = TextBox1.Text & "0"
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        TextBox1.Text = TextBox1.Text & "3"
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        TextBox1.Text = TextBox1.Text & "4"
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        TextBox1.Text = TextBox1.Text & "5"
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        TextBox1.Text = TextBox1.Text & "6"
    End Sub

    Private Sub Button5_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox1.Text = TextBox1.Text & "7"
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        TextBox1.Text = TextBox1.Text & "8"
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        TextBox1.Text = TextBox1.Text & "9"
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        TextBox1.Text = TextBox1.Text & "."
    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        TextBox1.Clear()
    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        secondnumber = Val(TextBox1.Text)
        If arithmeticprocess = "+" Then
            result = firstnumber + secondnumber
        End If
        If arithmeticprocess = "-" Then
            result = firstnumber - secondnumber
        End If
        If arithmeticprocess = "*" Then
            result = firstnumber * secondnumber
        End If
        If arithmeticprocess = "/" Then
            result = firstnumber / secondnumber
        End If
        TextBox1.Text = result
    End Sub
End Class

